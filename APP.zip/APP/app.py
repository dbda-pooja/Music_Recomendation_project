from types import MethodDescriptorType
from flask import Flask, app,render_template
from flask import request
from flask import redirect
from flask.helpers import url_for

app=Flask(__name__)
@app.route('/')
def Music_Recommender():
    return render_template('index.html')


@app.route('/Rec',methods=['GET','POST'])

def Recommender():
    if request.method=="POST":
        songname = request.form['Song']
        noOfRecommendations=request.form['No.ofRecomendations']
    '''
    importing necessary libraries
    '''
    import numpy as np
    import pymongo
    import pandas as pd

    '''
    Data cleaning 

    '''
    client = pymongo.MongoClient('localhost', 27017)
    db = client['mydb']
    collection = db['spotify']
    spotify_data = pd.DataFrame(list(collection.find()))
   # spotify_data=spotify_data.drop('_id',axis=1)
    '''
   normalization

   '''
    from sklearn.cluster import KMeans
    def normalize_column(col):
      """
     col - column in the dataframe which needs to be normalized
       """
      max_d =spotify_data[col].max()
      min_d = spotify_data[col].min()
      spotify_data[col] = (spotify_data[col] - min_d)/(max_d - min_d)
    
#Normalize allnumerical columns so that min value is 0 and max value is 1
    num_types = ['int16', 'int32', 'int64', 'float16', 'float32', 'float64']
    num = spotify_data.select_dtypes(include=num_types)
        
    for col in num.columns:
         normalize_column(col)
    
#perform Kmeans CLustering
    km = KMeans(n_clusters=35)
    pred = km.fit_predict(num)
    spotify_data['pred'] = pred
    normalize_column('pred')

    '''
    actual Recommendation
    '''
    class Spotify_Recommendation():
     def __init__(self, dataset):
        self.data_ = dataset
        print(self.data_)
     def get_recommendations(self, song_name, n_top):
        distances = []
        #choosing the given song_name and dropping it from the data
        song = self.data_[(self.data_.name.str.lower() == song_name.lower())].head(1).values[0]
        rem_data = self.data_[self.data_.name.str.lower() != song_name.lower()]
        for r_song in rem_data.values:
            dist = 0
            for col in np.arange(len(rem_data.columns)):
                #indeces of non-numerical columns(id,Release date,name,artists,date)
                if not col in [0,2,7,13,15,19]:
                    #calculating the manhettan distances for each numerical feature
                    dist = dist + np.absolute(float(song[col]) - float(r_song[col]))
            distances.append(dist)
        rem_data['distance'] = distances
        #sorting our data to be ascending by 'distance' feature
        rem_data = rem_data.sort_values('distance')
        columns = ['artists', 'name','year']
        return rem_data[columns][:n_top]
     
    
    print('xyz')
    print(songname)
    print(noOfRecommendations)
    recommendations = Spotify_Recommendation(spotify_data)
    x = recommendations.get_recommendations(str(songname),int(noOfRecommendations))
    #x.drop(columns=x.columns[0], 
     #   axis=1, 
      #  inplace=True)
    pd.set_option('colheader_justify', 'center')  
    return render_template("output.html",tables=[x.to_html(classes='data')], titles=x.columns.values)

   
     
         

if __name__=="__main__":
    app.run(debug=True,port=8000)